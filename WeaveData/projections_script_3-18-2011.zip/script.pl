 #
 # Institute for Visualization and Perception Research
 # Indicator Visualization Platform Framework
 #
 # Web-based data visualization and mapping framework.
 #
 #
 #
 # Copyright (c) 2009-10 Institute for Visualization and Perception Research
 # Department of Computer Science
 # University of Massachusetts Lowell
 # One University Ave.
 # Lowell, Massachusetts  01854
 # U.S.A.
 # All rights reserved.
 #
 # Warning: This computer software program, including all text, graphics, the
 # selection and arrangement thereof, the algorithms, the process, and all
 # other materials in this file, including its compilation are protected by
 # copyright law and international treaties. Unauthorized copying or altering
 # thereof, in hard or soft copy, or distribution of this program or any
 # portion thereof, is expressly forbidden without prior written consent and
 # may result in severe civil and criminal penalties, and will be prosecuted
 # to the maximum extent possible under the law. Additionally, all software
 # packages, compilations, and derivatives thereof, which include this file,
 # are protected as well. Use is subject to license terms.
 #

# @author: kmonico


# iterate over command line arguments
for ($i = 0; $i < $#ARGV + 1; $i++) {

    # open the file, read into string, close it
    $fileName = @ARGV[$i];
    $strFile = uc($fileName);
    open fileAll, $fileName or die "Couldn't open file: $!";
    $strAll = join("", <fileAll>);
    close fileAll;

    # split into array
    @projEntries = split(/<>/, $strAll);

    # for each projection entry in the array, strip out the necessary data
    foreach $strInput (@projEntries) {

        if ($strInput =~ m/(\+title=.+)\s*\+/) {
            $strTitle = $1;
        } elsif ($strInput =~ m/(#([\s\S]+))/) {
            @tempArray = split(/#/, $1);

            if (@tempArray[scalar(@tempArray) - 1] =~ m/\s*(.*)/) {
                $strTitle = "+title=" . $1;
            }
        }

        # get the hash code
        if ($strInput =~ m/<(.+)>/) {
            $sHashVal = $1;
        }

        # get rest of params
        if ($strInput =~ m/<.+>\s*([\s\S]*)/) {
            @arrayParams = split(/#.*/, $1);
            $strParameters = "";

	    # rebuild the result
            foreach (@arrayParams) {
                $strParameters = $strParameters . $_;
            }
        }

        # check each param has a + in front
        # first split strParameters by spaces
        @arrayParams = split(/\s+/, $strParameters);
        $strParameters = "";
        foreach $strInArrayParams (@arrayParams) {

            # if there isn't a + in front and it's not just whitespace
            if ($strInArrayParams !~ m/\+.*$/ && length($strInArrayParams) > 0) {
                $strInArrayParams = "+" . $strInArrayParams;
            }

            $strParameters = $strParameters . $strInArrayParams . " ";
        }

        # ProjProjection.defs['EPSG:4014'] = "+title some long title +proj +restofparams"
	# CSV input
	# "EPSG:4014","+title +..."
        # ProjProjection.defs['EPSG:4014'] = "+title some long title +proj +restofparams"
        printf("ProjProjection.defs[\'%s:%s\'] = \"%s %s\";\n\n", $strFile, uc($sHashVal), $strTitle, $strParameters);
        #printf("\"%s:%s\",\"%s %s\"\n", $strFile, uc($sHashVal), $strTitle, $strParameters);
    }

}


