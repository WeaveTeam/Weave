To use this script, install Strawberry Perl (Windows) or any other Perl implementation for your OS.

Then do

perl script.pl file1 file2 file3

Where file1, file2, file3 are files to be parsed. In this zip, file1 would be epsg, file2 esri, up to to the world file. You should redirect the output, for example.


perl script.pl epsg > epsgoutput.txt

perl script.pl epsg esri esri.extra nad27 nad83 > newoutput.txt

The purpose of "> file.txt" is to redirect the output. Otherwise, the script prints to the standard output (screen), which is very slow.

You can supply as many files to the script as you need.


ProjectionDatabase.as was used to create ProjectionDatabase.dat as follows:

var ba:ByteArray = new ByteArray();
ba.writeObject(new ProjectionDatabase());
ba.compress();
new FileReference().save(ba);
